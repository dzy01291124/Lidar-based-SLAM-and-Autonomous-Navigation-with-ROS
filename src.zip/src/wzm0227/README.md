# xju-robot project
XJU robot project for algorithm teaching.<br>
Code and teaching video are being revised and updated periodically.<br>
Thanks for watching and please kindly leave one STAR for us.

Class 1: build simulation environment.<br>
Video link: 【XJU移动机器人仿真-第1期 环境搭建（gazebo模型 插件 urdf rviz）】 https://www.bilibili.com/video/BV1be4y1z7cr?share_source=copy_web&vd_source=88e435df3261250165e3c0b331a63754

Class 2: bridge and debug tools.<br>
Video link: 【XJU移动机器人仿真-第2期 数据分析（msg设计，rqtbag，plotjuggler）】 https://www.bilibili.com/video/BV1RP411E7m7?share_source=copy_web&vd_source=88e435df3261250165e3c0b331a63754

Class 3: mapping and localization.<br>
Video link: 【XJU移动机器人仿真-第3期 建图定位（gmapping、AMCL、rangeRelocation）】 https://www.bilibili.com/video/BV1E14y1h7uY?share_source=copy_web&vd_source=88e435df3261250165e3c0b331a63754

Class 4: planning and control.<br>
Video link: 【XJU移动机器人仿真-第4期 点到点导航（movebase、costmap、teb）】 https://www.bilibili.com/video/BV1M8411s79i?share_source=copy_web&vd_source=88e435df3261250165e3c0b331a63754

Class 5: a-slam.<br>
Video link:【XJU移动机器人仿真-第5期 探索建图（A-SLAM、Exploration）】 https://www.bilibili.com/video/BV1KN4y1w7vR?share_source=copy_web&vd_source=88e435df3261250165e3c0b331a63754

